package com.example.payment.controller;

import com.example.payment.data.Payment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.payment.service.PaymentService;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/pay")

public class PaymentController {


        //get all users
        @Autowired
        private PaymentService paymentService;

        @GetMapping(path = "/payments")
        public List<Payment> findAllPayments() {

                return paymentService.getPayment();
        }

        // read user for given id
        @GetMapping(path = "/payments/{payId}")
        public Payment findPaymentById(@PathVariable int payId) {

                return paymentService.getPaymentId(payId);
        }


        @PostMapping(path = "/payments")
        public Payment createPayment(@RequestBody Payment payment) {
                return paymentService.createPayment(payment);
        }
}


