package com.example.ECommerce2.controller;

import com.example.ECommerce2.data.CartRepository;
import com.example.ECommerce2.data.Cart;
import com.example.ECommerce2.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    @GetMapping("/products")
    public List<Cart> getAllCarts() {
        return cartService.getAllCarts();
    }


    @GetMapping("/products/{title}")
    public ResponseEntity<Cart> findCartByTitle(@PathVariable String title) {
        return cartService.getCartByTitle(title)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }


    @PutMapping("/products/{product_id}")
    public ResponseEntity<Cart> updateCart(@PathVariable int product_id, @RequestBody Cart cartDetails) {
        Cart updatedCart = cartService.updateCart(product_id, cartDetails);
        if (updatedCart != null) {
            return ResponseEntity.ok(updatedCart);
        }
        return ResponseEntity.notFound().build();
    }

    @DeleteMapping("/products/{product_id}")
    public ResponseEntity<Void> deleteCart(@PathVariable int product_id) {
        System.out.println("Received request to delete product ID: " + product_id); // Add logging
        if (cartService.deleteCart(product_id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }

    @PostMapping("/products")
    public ResponseEntity<Cart> createCart(@RequestBody Cart cart) {
        // Calculate total based on price and quantity
        cart.setTotal(cart.getPrice() * cart.getQuantity());
        Cart createdCart = cartService.createCart(cart);

        return ResponseEntity.ok(createdCart);
    }
}

