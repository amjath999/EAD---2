package com.example.ECommerce2.service;

import com.example.ECommerce2.data.Cart;
import com.example.ECommerce2.data.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    public List<Cart> getAllCarts() {
        return cartRepository.findAll();
    }

    public Optional<Cart> getCartByTitle(String title) {
        return cartRepository.findByTitle(title);
    }

    public Cart createCart(Cart cart) {
        return cartRepository.save(cart);
    }

    public Cart updateCart(int productId, Cart cartDetails) {
        Optional<Cart> optionalCart = cartRepository.findById(productId);
        if (optionalCart.isPresent()) {
            Cart cart = optionalCart.get();
            cart.setTitle(cartDetails.getTitle());
            cart.setPrice(cartDetails.getPrice());
            cart.setCategory(cartDetails.getCategory());
            cart.setSize(cartDetails.getSize());
            cart.setQuantity(cartDetails.getQuantity());
            cart.setTotal(cartDetails.getTotal());
            return cartRepository.save(cart);
        }
        return null;
    }

    public boolean deleteCart(int product_id) {
        System.out.println("Attempting to delete product with ID: " + product_id);
        try {
            cartRepository.deleteById(product_id);
            return true;
        } catch (Exception e) {
            System.out.println("Error deleting product: " + e.getMessage());
            return false;
        }
    }

}
