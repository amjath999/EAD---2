package com.example.ECommerce.controller;

import com.example.ECommerce.data.User;
import com.example.ECommerce.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/login")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping(path = "/users/login")
    public User createUsers(@RequestBody User user)
    {
        return userService.createUser(user);
    }

    @GetMapping(path = "/users")
    public List<User> findAllUsers()
    {
        return userService.getUser();
    }
    @GetMapping(path = "/users/{userId}")
    public User findUserById(@PathVariable int userId)
    {
        return userService.getUserById(userId);
    }


}
